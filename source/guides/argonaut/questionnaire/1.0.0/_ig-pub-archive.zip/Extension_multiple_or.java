package http://fhir.org/guides/argonaut/questionnaire/ImplementationGuide/fhir.argonaut.questionnaire-1.0.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class Extension_multiple_or {

}
