# fhir-ig-history-template

History page for IG templates

for further information, see <http://wiki.hl7.org/index.php?title=Process_for_Publishing_a_FHIR_IG>

