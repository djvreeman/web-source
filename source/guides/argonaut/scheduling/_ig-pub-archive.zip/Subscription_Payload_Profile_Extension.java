package http://fhir.org/guides/argonaut-scheduling/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class Subscription_Payload_Profile_Extension {

}
